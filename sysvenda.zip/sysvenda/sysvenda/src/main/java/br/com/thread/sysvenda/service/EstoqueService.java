package br.com.thread.sysvenda.service;

import br.com.thread.sysvenda.domain.Produto;
import br.com.thread.sysvenda.domain.dto.ResultadoChecagem;
import br.com.thread.sysvenda.repository.ProdutoRepository;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class EstoqueService {

    private final ProdutoRepository produtoRepository;

    public EstoqueService(ProdutoRepository produtoRepository) {
        this.produtoRepository = produtoRepository;
    }

    public List<ResultadoChecagem> checarSequencial(List<Long> ids) {
        List<ResultadoChecagem> resultados = new ArrayList<>();

        for (int i = 0; i < ids.size(); i++) {
            Long id = ids.get(i);
            ResultadoChecagem resultado = checarEstoque(id);
            resultados.add(resultado);
        }

        return resultados;
    }

    public List<ResultadoChecagem> checarParalelo(List<Long> ids, int tamanhoBloco) {
        List<ResultadoChecagem> resultados = Collections.synchronizedList(new ArrayList<>());
        List<Thread> threads = new ArrayList<>();

        for (int i = 0; i < ids.size(); i += tamanhoBloco) {
            int fim = Math.min(i + tamanhoBloco, ids.size());
            final List<Long> sublista = ids.subList(i, fim);

            Thread t = new Thread(new Runnable() {
                @Override
                public void run() {
                    for (int j = 0; j < sublista.size(); j++) {
                        Long id = sublista.get(j);
                        ResultadoChecagem resultado = checarEstoque(id);
                        resultados.add(resultado);
                    }
                }
            });

            threads.add(t);
            t.start();
        }

        for (int i = 0; i < threads.size(); i++) {
            try {
                threads.get(i).join();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                System.err.println("Thread interrompida: " + e.getMessage());
            }
        }

        return resultados;
    }

    private ResultadoChecagem checarEstoque(Long idProduto) {
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            System.err.println("Erro no delay simulado: " + e.getMessage());
        }

        Optional<Produto> produto = produtoRepository.findById(idProduto);
        if (produto.isPresent()) {
            Produto p = produto.get();
            return new ResultadoChecagem(p.getId(), p.getQuantidadeEstoque() > 0);
        } else {
            return new ResultadoChecagem(idProduto, false);
        }
    }
}