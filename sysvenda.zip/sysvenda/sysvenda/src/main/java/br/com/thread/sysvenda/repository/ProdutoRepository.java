package br.com.thread.sysvenda.repository;

import br.com.thread.sysvenda.domain.Produto;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProdutoRepository extends JpaRepository<Produto, Long> {
}