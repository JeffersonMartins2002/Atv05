package br.com.thread.sysvenda;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SysvendaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SysvendaApplication.class, args);
	}

}
