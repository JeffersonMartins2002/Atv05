package br.com.thread.sysvenda;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SysvendaApplicationTests {

	@Test
	void contextLoads() {
	}

}
