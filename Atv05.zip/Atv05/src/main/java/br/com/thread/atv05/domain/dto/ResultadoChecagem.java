package br.com.thread.sysvenda.domain.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ResultadoChecagem {
    private Long idProduto;
    private Boolean disponivel;
}