package br.com.thread.sysvenda.service;

import br.com.thread.sysvenda.domain.Produto;
import br.com.thread.sysvenda.domain.dto.ResultadoChecagem;
import br.com.thread.sysvenda.repository.ProdutoRepository;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class EstoqueService {
    private final ProdutoRepository produtoRepository;

    public EstoqueService(ProdutoRepository produtoRepository) {
        this.produtoRepository = produtoRepository;
    }

    public List<ResultadoChecagem> checarSequencial(List<Long> ids) {
        List<ResultadoChecagem> resultados = new ArrayList<>();
        for (Long id : ids) {
            resultados.add(checarEstoque(id));
        }
        return resultados;
    }

    public List<ResultadoChecagem> checarParalelo(List<Long> ids, int tamanhoBloco) {
        List<ResultadoChecagem> resultados = Collections.synchronizedList(new ArrayList<>());
        List<List<Long>> blocos = dividirEmBlocos(ids, tamanhoBloco);
        List<Thread> threads = new ArrayList<>();

        for (List<Long> bloco : blocos) {
            Thread t = new Thread(() -> {
                for (Long id : bloco) {
                    resultados.add(checarEstoque(id));
                }
            });
            threads.add(t);
            t.start();
        }

        for (Thread t : threads) {
            try {
                t.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        return resultados;
    }

    private List<List<Long>> dividirEmBlocos(List<Long> ids, int tamanhoBloco) {
        List<List<Long>> blocos = new ArrayList<>();
        for (int i = 0; i < ids.size(); i += tamanhoBloco) {
            int fim = Math.min(i + tamanhoBloco, ids.size());
            blocos.add(ids.subList(i, fim));
        }
        return blocos;
    }

    private ResultadoChecagem checarEstoque(Long idProduto) {
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        Optional<Produto> produto = produtoRepository.findById(idProduto);
        return produto.map(p -> new ResultadoChecagem(p.getId(), p.getQuantidadeEstoque() > 0))
                      .orElseGet(() -> new ResultadoChecagem(idProduto, false));
    }
}