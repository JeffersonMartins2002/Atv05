package br.com.thread.sysvenda.controller;

import br.com.thread.sysvenda.domain.dto.ChecagemEstoqueRequest;
import br.com.thread.sysvenda.domain.dto.ResultadoChecagem;
import br.com.thread.sysvenda.service.EstoqueService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/estoque")
public class EstoqueController {

    private final EstoqueService estoqueService;

    public EstoqueController(EstoqueService estoqueService) {
        this.estoqueService = estoqueService;
    }

    @PostMapping("/checar-sequencial")
    public List<ResultadoChecagem> checarSequencial(@RequestBody ChecagemEstoqueRequest request) {
        long inicio = System.currentTimeMillis();
        List<ResultadoChecagem> resultado = estoqueService.checarSequencial(request.getIdsProdutos());
        long fim = System.currentTimeMillis();
        System.out.println("Tempo SEQUENCIAL: " + (fim - inicio) + " ms");
        return resultado;
    }

    @PostMapping("/checar-paralelo")
    public List<ResultadoChecagem> checarParalelo(
            @RequestBody ChecagemEstoqueRequest request,
            @RequestParam(defaultValue = "10") int tamanhoBloco
    ) {
        long inicio = System.currentTimeMillis();
        List<ResultadoChecagem> resultado = estoqueService.checarParalelo(request.getIdsProdutos(), tamanhoBloco);
        long fim = System.currentTimeMillis();
        System.out.println("Tempo PARALELO: " + (fim - inicio) + " ms");
        return resultado;
    }
}